import { Card } from "@/components/ui/card";
import { Clock, TrendingUp } from "lucide-react";

interface TimeData {
  hour: string;
  demand: number;
  supply: number;
  cancellations: number;
}

const mockTimeData: TimeData[] = [
  { hour: "6AM", demand: 120, supply: 90, cancellations: 15 },
  { hour: "7AM", demand: 280, supply: 180, cancellations: 45 },
  { hour: "8AM", demand: 420, supply: 220, cancellations: 85 },
  { hour: "9AM", demand: 380, supply: 280, cancellations: 35 },
  { hour: "10AM", demand: 320, supply: 310, cancellations: 12 },
  { hour: "11AM", demand: 290, supply: 320, cancellations: 8 },
  { hour: "12PM", demand: 350, supply: 300, cancellations: 25 },
  { hour: "1PM", demand: 380, supply: 290, cancellations: 35 },
  { hour: "2PM", demand: 320, supply: 310, cancellations: 15 },
  { hour: "3PM", demand: 290, supply: 300, cancellations: 12 },
  { hour: "4PM", demand: 340, supply: 280, cancellations: 28 },
  { hour: "5PM", demand: 480, supply: 260, cancellations: 95 },
  { hour: "6PM", demand: 520, supply: 240, cancellations: 125 },
  { hour: "7PM", demand: 450, supply: 280, cancellations: 75 },
  { hour: "8PM", demand: 380, supply: 320, cancellations: 35 },
  { hour: "9PM", demand: 320, supply: 340, cancellations: 18 },
];

export function TimeSeriesChart() {
  const maxValue = Math.max(...mockTimeData.flatMap(d => [d.demand, d.supply, d.cancellations]));
  
  const getBarHeight = (value: number) => `${(value / maxValue) * 100}%`;
  
  const getGapPercentage = (demand: number, supply: number) => {
    const gap = demand - supply;
    return gap > 0 ? ((gap / demand) * 100).toFixed(1) : "0";
  };

  return (
    <Card className="p-6 bg-card">
      <div className="flex items-center gap-2 mb-6">
        <Clock className="h-5 w-5 text-primary" />
        <h3 className="text-lg font-semibold text-foreground">Hourly Demand vs Supply Analysis</h3>
      </div>

      {/* Chart */}
      <div className="relative mb-6">
        <div className="flex items-end justify-between gap-1 h-64 px-2">
          {mockTimeData.map((data, index) => (
            <div key={index} className="flex-1 flex flex-col items-center gap-1 group">
              {/* Bars container */}
              <div className="flex items-end gap-0.5 h-48 w-full justify-center">
                {/* Demand bar */}
                <div className="relative flex-1 max-w-3">
                  <div 
                    className="bg-primary rounded-t-sm transition-all duration-300 group-hover:bg-primary-light"
                    style={{ height: getBarHeight(data.demand) }}
                  ></div>
                  <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity text-xs text-foreground font-medium">
                    {data.demand}
                  </div>
                </div>
                
                {/* Supply bar */}
                <div className="relative flex-1 max-w-3">
                  <div 
                    className="bg-secondary rounded-t-sm transition-all duration-300 group-hover:bg-secondary-light"
                    style={{ height: getBarHeight(data.supply) }}
                  ></div>
                  <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity text-xs text-foreground font-medium">
                    {data.supply}
                  </div>
                </div>
                
                {/* Cancellations bar */}
                <div className="relative flex-1 max-w-3">
                  <div 
                    className="bg-destructive rounded-t-sm transition-all duration-300 group-hover:bg-destructive/80"
                    style={{ height: getBarHeight(data.cancellations) }}
                  ></div>
                  <div className="absolute -top-6 left-1/2 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity text-xs text-foreground font-medium">
                    {data.cancellations}
                  </div>
                </div>
              </div>
              
              {/* Hour label */}
              <div className="text-xs text-muted-foreground font-medium transform -rotate-45 mt-2">
                {data.hour}
              </div>
              
              {/* Gap indicator */}
              {parseInt(getGapPercentage(data.demand, data.supply)) > 10 && (
                <div className="w-2 h-2 bg-warning rounded-full animate-pulse mt-1"></div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Legend */}
      <div className="flex items-center justify-center gap-6 mb-4 text-sm">
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-primary rounded"></div>
          <span className="text-muted-foreground">Demand</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-secondary rounded"></div>
          <span className="text-muted-foreground">Supply</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-3 h-3 bg-destructive rounded"></div>
          <span className="text-muted-foreground">Cancellations</span>
        </div>
      </div>

      {/* Key Insights */}
      <div className="p-4 bg-muted/50 rounded-lg">
        <div className="flex items-center gap-2 mb-2">
          <TrendingUp className="h-4 w-4 text-warning" />
          <span className="text-sm font-medium text-foreground">Peak Hours Analysis</span>
        </div>
        <p className="text-sm text-muted-foreground">
          Critical supply gaps occur during 7-8AM (100+ demand excess) and 5-6PM (280+ demand excess), 
          correlating with highest cancellation rates of 85 and 125 respectively.
        </p>
      </div>
    </Card>
  );
}