import { Card } from "@/components/ui/card";
import { MapPin, AlertTriangle } from "lucide-react";

interface HeatMapZone {
  id: string;
  name: string;
  cancellationRate: number;
  coordinates: { x: number; y: number };
  severity: "high" | "medium" | "low";
}

const mockZones: HeatMapZone[] = [
  { id: "1", name: "Times Square", cancellationRate: 23.5, coordinates: { x: 45, y: 35 }, severity: "high" },
  { id: "2", name: "Brooklyn Bridge", cancellationRate: 18.2, coordinates: { x: 65, y: 55 }, severity: "medium" },
  { id: "3", name: "Central Park", cancellationRate: 15.1, coordinates: { x: 50, y: 25 }, severity: "medium" },
  { id: "4", name: "JFK Airport", cancellationRate: 28.7, coordinates: { x: 85, y: 75 }, severity: "high" },
  { id: "5", name: "LaGuardia", cancellationRate: 31.2, coordinates: { x: 35, y: 15 }, severity: "high" },
  { id: "6", name: "Financial District", cancellationRate: 12.4, coordinates: { x: 60, y: 80 }, severity: "low" },
];

export function HeatMapCard() {
  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "high":
        return "bg-destructive text-destructive-foreground";
      case "medium":
        return "bg-warning text-warning-foreground";
      default:
        return "bg-success text-success-foreground";
    }
  };

  const getSeverityDot = (severity: string) => {
    switch (severity) {
      case "high":
        return "bg-destructive animate-pulse";
      case "medium":
        return "bg-warning";
      default:
        return "bg-success";
    }
  };

  return (
    <Card className="p-6 bg-card">
      <div className="flex items-center gap-2 mb-6">
        <MapPin className="h-5 w-5 text-primary" />
        <h3 className="text-lg font-semibold text-foreground">NYC Cancellation Heat Map</h3>
      </div>

      <div className="relative">
        {/* NYC Map Background */}
        <div className="bg-gradient-data rounded-lg p-8 relative overflow-hidden min-h-[300px]">
          {/* Grid lines for NYC borough representation */}
          <div className="absolute inset-0 opacity-20">
            <div className="grid grid-cols-8 grid-rows-6 h-full">
              {Array.from({ length: 48 }).map((_, i) => (
                <div key={i} className="border border-primary/20"></div>
              ))}
            </div>
          </div>

          {/* Heat map zones */}
          {mockZones.map((zone) => (
            <div
              key={zone.id}
              className="absolute transform -translate-x-1/2 -translate-y-1/2 group cursor-pointer"
              style={{ left: `${zone.coordinates.x}%`, top: `${zone.coordinates.y}%` }}
            >
              <div className={`w-4 h-4 rounded-full ${getSeverityDot(zone.severity)} ring-4 ring-white/30 transition-all duration-300 group-hover:scale-150`}></div>
              
              {/* Tooltip */}
              <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity duration-300 z-10">
                <div className="bg-card border border-border rounded-lg p-3 shadow-strong min-w-max">
                  <div className="text-sm font-medium text-foreground">{zone.name}</div>
                  <div className="text-xs text-muted-foreground">Cancellation Rate</div>
                  <div className={`text-sm font-bold ${zone.severity === 'high' ? 'text-destructive' : zone.severity === 'medium' ? 'text-warning' : 'text-success'}`}>
                    {zone.cancellationRate}%
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Legend */}
        <div className="mt-4 flex items-center justify-center gap-6 text-sm">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-success"></div>
            <span className="text-muted-foreground">Low (&lt;15%)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-warning"></div>
            <span className="text-muted-foreground">Medium (15-25%)</span>
          </div>
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-destructive animate-pulse"></div>
            <span className="text-muted-foreground">High (&gt;25%)</span>
          </div>
        </div>
      </div>

      {/* Key Insights */}
      <div className="mt-6 p-4 bg-muted/50 rounded-lg">
        <div className="flex items-center gap-2 mb-2">
          <AlertTriangle className="h-4 w-4 text-warning" />
          <span className="text-sm font-medium text-foreground">Key Insight</span>
        </div>
        <p className="text-sm text-muted-foreground">
          Airport zones (JFK, LaGuardia) show highest cancellation rates at 28.7% and 31.2% respectively, 
          indicating supply-demand imbalance during peak travel times.
        </p>
      </div>
    </Card>
  );
}