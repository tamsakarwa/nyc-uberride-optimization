import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, Target, DollarSign, Users, Clock } from "lucide-react";

interface Recommendation {
  id: string;
  title: string;
  description: string;
  impact: "High" | "Medium" | "Low";
  effort: "High" | "Medium" | "Low";
  category: "Supply" | "Demand" | "Technology" | "Incentives";
  expectedImprovement: string;
  icon: React.ReactNode;
}

const recommendations: Recommendation[] = [
  {
    id: "1",
    title: "Dynamic Surge Pricing for Drivers", 
    description: "Implement predictive surge pricing 30 minutes before peak hours in high-cancellation zones to attract more drivers preemptively.",
    impact: "High",
    effort: "Medium",
    category: "Incentives",
    expectedImprovement: "25-30% reduction in cancellations",
    icon: <DollarSign className="h-4 w-4" />
  },
  {
    id: "2",
    title: "Airport Dedicated Driver Pool",
    description: "Create dedicated driver pools for JFK and LaGuardia with guaranteed earnings to ensure consistent supply during peak travel times.",
    impact: "High", 
    effort: "High",
    category: "Supply",
    expectedImprovement: "40% reduction in airport cancellations",
    icon: <Users className="h-4 w-4" />
  },
  {
    id: "3",
    title: "AI-Powered Driver Repositioning",
    description: "Use ML algorithms to proactively suggest optimal positioning to drivers based on predicted demand patterns.",
    impact: "Medium",
    effort: "High", 
    category: "Technology",
    expectedImprovement: "15-20% improvement in response times",
    icon: <Target className="h-4 w-4" />
  },
  {
    id: "4",
    title: "Peak Hour Pre-Booking Incentives",
    description: "Offer discounted rides for customers who book 15+ minutes in advance during identified peak periods.",
    impact: "Medium",
    effort: "Low",
    category: "Demand",
    expectedImprovement: "10% demand smoothing",
    icon: <Clock className="h-4 w-4" />
  }
];

export function RecommendationsCard() {
  const getImpactColor = (impact: string) => {
    switch (impact) {
      case "High":
        return "bg-success text-success-foreground";
      case "Medium":
        return "bg-warning text-warning-foreground";
      default:
        return "bg-muted text-muted-foreground";
    }
  };

  const getEffortColor = (effort: string) => {
    switch (effort) {
      case "High":
        return "bg-destructive/10 text-destructive border-destructive/20";
      case "Medium":
        return "bg-warning/10 text-warning border-warning/20";
      default:
        return "bg-success/10 text-success border-success/20";
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "Supply":
        return "bg-primary/10 text-primary border-primary/20";
      case "Demand":
        return "bg-secondary/10 text-secondary border-secondary/20";
      case "Technology":
        return "bg-accent/10 text-accent border-accent/20";
      default:
        return "bg-muted/10 text-muted-foreground border-muted/20";
    }
  };

  return (
    <Card className="p-6 bg-card">
      <div className="flex items-center gap-2 mb-6">
        <CheckCircle className="h-5 w-5 text-success" />
        <h3 className="text-lg font-semibold text-foreground">Strategic Recommendations</h3>	
      </div>

      <div className="space-y-4">
        {recommendations.map((rec, index) => (
          <div 
            key={rec.id} 
            className="p-4 border border-border/50 rounded-lg hover:shadow-soft transition-all duration-300 bg-card/50"
          >
            <div className="flex items-start justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className="text-primary">{rec.icon}</div>
                <div>
                  <h4 className="font-semibold text-foreground">{rec.title}</h4>
                  <p className="text-sm text-muted-foreground mt-1">{rec.description}</p>
                </div>
              </div>
              <div className="text-right">
                <div className="text-xs text-muted-foreground mb-1">Priority</div>
                <div className="text-lg font-bold text-foreground">#{index + 1}</div>
              </div>
            </div>

            <div className="flex items-center gap-2 mb-3">
              <Badge className={getImpactColor(rec.impact)}>
                Impact: {rec.impact}
              </Badge>
              <Badge variant="outline" className={getEffortColor(rec.effort)}>
                Effort: {rec.effort}
              </Badge>
              <Badge variant="outline" className={getCategoryColor(rec.category)}>
                {rec.category}
              </Badge>
            </div>

            <div className="p-3 bg-muted/30 rounded-md">
              <div className="text-xs text-muted-foreground mb-1">Expected Improvement</div>
              <div className="text-sm font-medium text-foreground">{rec.expectedImprovement}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Implementation Timeline */}
      <div className="mt-6 p-4 bg-primary/5 border border-primary/20 rounded-lg">
        <h4 className="font-semibold text-foreground mb-2">Recommended Implementation Timeline</h4>
        <div className="text-sm text-muted-foreground space-y-1">
          <div><strong>Phase 1 (0-3 months):</strong> Peak Hour Pre-Booking Incentives</div>
          <div><strong>Phase 2 (3-6 months):</strong> Dynamic Surge Pricing Implementation</div>
          <div><strong>Phase 3 (6-12 months):</strong> Airport Dedicated Driver Pool & AI Repositioning</div>
        </div>
      </div>
    </Card>
  );
}