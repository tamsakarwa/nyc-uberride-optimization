import { MetricCard } from "@/components/MetricCard";
import { HeatMapCard } from "@/components/HeatMapCard";
import { TimeSeriesChart } from "@/components/TimeSeriesChart";
import { RecommendationsCard } from "@/components/RecommendationsCard";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Car, 
  XCircle, 
  Clock, 
  TrendingUp, 
  BarChart3, 
  Database, 
  Brain,
  Presentation,
  MapPin,
  Target
} from "lucide-react";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-hero py-16 px-6">
        <div className="absolute inset-0 bg-grid-pattern opacity-10"></div>
        <div className="relative max-w-7xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm rounded-full px-4 py-2 mb-6">
            <MapPin className="h-4 w-4 text-white" />
            <span className="text-white text-sm font-medium">Data Analytics Portfolio Project</span>
          </div>
          
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight">
            Solving Uber's NYC 
            <br />
            <span className="text-primary-glow">Cancellation Crisis</span>
          </h1>
          
          <p className="text-xl text-white/90 mb-8 max-w-3xl mx-auto leading-relaxed">
            Comprehensive data analysis of ride request patterns, cancellation rates, and driver utilization 
            to identify high-impact solutions for reducing cancellations and optimizing driver allocation in New York City.
          </p>
          
          <div className="flex flex-wrap justify-center gap-3 mb-8">
            <Badge className="bg-white/20 text-white border-white/30 px-4 py-2">
              <Database className="h-4 w-4 mr-2" />
              SQL Analysis
            </Badge>
            <Badge className="bg-white/20 text-white border-white/30 px-4 py-2">
              <BarChart3 className="h-4 w-4 mr-2" />
              Tableau
            </Badge>
            <Badge className="bg-white/20 text-white border-white/30 px-4 py-2">
              <Brain className="h-4 w-4 mr-2" />
              Python ML
            </Badge>
            <Badge className="bg-white/20 text-white border-white/30 px-4 py-2">
              <Presentation className="h-4 w-4 mr-2" />
              PowerBI
            </Badge>
          </div>
        </div>
      </section>

      {/* Problem Statement */}
      <section className="py-16 px-6">
        <div className="max-w-7xl mx-auto">
          <Card className="p-8 bg-gradient-data border-none shadow-medium">
            <div className="text-center mb-8">
              <h2 className="text-3xl font-bold text-foreground mb-4">The Challenge</h2>
              <p className="text-lg text-muted-foreground max-w-4xl mx-auto">
                Uber NYC faces a critical supply-demand imbalance leading to increased cancellations, 
                longer wait times, and reduced customer satisfaction. Our analysis identifies key patterns 
                and provides actionable recommendations to optimize the ride-sharing ecosystem.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center p-6 bg-card/50 rounded-lg border border-border/50">
                <XCircle className="h-12 w-12 text-destructive mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-foreground mb-2">High Cancellation Rates</h3>
                <p className="text-muted-foreground">23.5% average cancellation rate in peak zones</p>
              </div>
              
              <div className="text-center p-6 bg-card/50 rounded-lg border border-border/50">
                <Clock className="h-12 w-12 text-warning mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-foreground mb-2">Extended Wait Times</h3>
                <p className="text-muted-foreground">12+ minute average wait during rush hours</p>
              </div>
              
              <div className="text-center p-6 bg-card/50 rounded-lg border border-border/50">
                <Car className="h-12 w-12 text-primary mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-foreground mb-2">Driver Shortage</h3>
                <p className="text-muted-foreground">40% supply deficit during peak demand</p>
              </div>
            </div>
          </Card>
        </div>
      </section>

      {/* Key Metrics */}
      <section className="py-16 px-6 bg-muted/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">Key Performance Indicators</h2>
            <p className="text-lg text-muted-foreground">
              Real-time analysis of critical metrics driving cancellation patterns
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <MetricCard
              title="Overall Cancellation Rate"
              value="18.7%"
              change={-3.2}
              changeType="decrease"
              icon={<XCircle className="h-5 w-5" />}
              description="vs last month"
            />
            
            <MetricCard
              title="Peak Hour Supply Gap"
              value="34%"
              change={5.1}
              changeType="increase"
              icon={<Car className="h-5 w-5" />}
              description="demand exceeds supply"
            />
            
            <MetricCard
              title="Average Wait Time"
              value="8.3 min"
              change={-1.8}
              changeType="decrease"
              icon={<Clock className="h-5 w-5" />}
              description="city-wide average"
            />
            
            <MetricCard
              title="Driver Utilization"
              value="73%"
              change={2.4}
              changeType="increase"
              icon={<TrendingUp className="h-5 w-5" />}
              description="active driving time"
            />
          </div>
        </div>
      </section>

      {/* Analysis Dashboard */}
      <section className="py-16 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">Data Analysis Dashboard</h2>
            <p className="text-lg text-muted-foreground">
              Interactive visualizations revealing critical patterns and insights
            </p>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
            <HeatMapCard />
            <TimeSeriesChart />
          </div>
          
          <RecommendationsCard />
        </div>
      </section>

      {/* Technical Stack */}
      <section className="py-16 px-6 bg-muted/30">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">Technical Implementation</h2>
            <p className="text-lg text-muted-foreground">
              Advanced analytics tools and methodologies employed in this analysis
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="p-6 text-center hover:shadow-medium transition-all duration-300">
              <Database className="h-12 w-12 text-primary mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-foreground mb-2">SQL Analysis</h3>
              <p className="text-sm text-muted-foreground">
                Complex queries for ride pattern analysis, cancellation correlations, and driver utilization metrics
              </p>
            </Card>
            
            <Card className="p-6 text-center hover:shadow-medium transition-all duration-300">
              <Brain className="h-12 w-12 text-secondary mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-foreground mb-2">Python ML</h3>
              <p className="text-sm text-muted-foreground">
                Predictive modeling for demand forecasting, clustering analysis, and optimization algorithms
              </p>
            </Card>
            
            <Card className="p-6 text-center hover:shadow-medium transition-all duration-300">
              <BarChart3 className="h-12 w-12 text-accent mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-foreground mb-2">Tableau</h3>
              <p className="text-sm text-muted-foreground">
                Interactive dashboards, geographic heat maps, and dynamic time-series visualizations
              </p>
            </Card>
            
            <Card className="p-6 text-center hover:shadow-medium transition-all duration-300">
              <Presentation className="h-12 w-12 text-warning mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-foreground mb-2">PowerBI</h3>
              <p className="text-sm text-muted-foreground">
                Executive reporting, KPI tracking, and strategic recommendation presentations
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 px-6 bg-gradient-hero">
        <div className="max-w-4xl mx-auto text-center">
          <Target className="h-16 w-16 text-white mx-auto mb-6" />
          <h2 className="text-3xl font-bold text-white mb-4">Ready to Optimize Your Operations?</h2>
          <p className="text-xl text-white/90 mb-8">
            This comprehensive analysis demonstrates proven methodologies for solving complex 
            supply-demand challenges in urban mobility. Let's discuss how similar insights 
            can drive growth for your organization.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="px-8 py-3 bg-white text-primary font-semibold rounded-lg hover:shadow-strong transition-all duration-300 hover:scale-105">
              View Full Analysis
            </button>
            <button className="px-8 py-3 border border-white/30 text-white font-semibold rounded-lg hover:bg-white/10 transition-all duration-300">
              Download Report
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Index;